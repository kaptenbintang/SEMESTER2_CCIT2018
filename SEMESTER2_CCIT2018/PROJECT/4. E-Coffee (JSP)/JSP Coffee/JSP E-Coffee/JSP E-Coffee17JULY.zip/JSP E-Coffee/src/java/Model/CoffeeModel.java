/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Koneksi.Koneksi;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author M.Dani Setiawan
 */
public class CoffeeModel {
   String id_booking,nama_tim,no_lapangan,hari,jam, ida;
   String id_akun,nama,email,password_akun;
   String id_admin,username,passoword_admin;
   String id_coffee,coffee_name,stock,price,expired;
   Koneksi db = null;
  
    public CoffeeModel() {
        db = new Koneksi();
    }

    public void setId_admin(String id_admin) {
        this.id_admin = id_admin;
    }

    public String getId_admin() {
        return id_admin;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setPassoword_admin(String passoword_admin) {
        this.passoword_admin = passoword_admin;
    }

    public String getPassoword_admin() {
        return passoword_admin;
    }

    public void setId_akun(String id_akun) {
        this.id_akun = id_akun;
    }

    public String getId_akun() {
        return id_akun;
    }

    

 
     public String getNama() {
        return nama;
    }
 
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public String getEmail() {
        return email;
    }
 
    public void setEmail(String email) {
        this.email = email;
    }
    
       public String getPassword() {
        return password_akun;
    }
 
    public void setPassword(String password) {
        this.password_akun = password;
    }

   
    public void simpan_coffee(){
        String sql="INSERT INTO db_coffee_detail values('"+coffee_name+"','"+stock+"','"+price+"','"+expired+"')";
        db.simpanData(sql);
    }
    
    public void update_coffee(){
        String sql="UPDATE db_coffee_detail SET coffee_name='"+coffee_name+"',stock='"+stock+"',price='"+price+"',expired='"+expired+"' WHERE id_coffee='"+id_coffee+"'";
        db.simpanData(sql);
        System.out.println(sql);
    }
    public void hapus_coffee(){
        String sql="DELETE FROM db_coffee_detail WHERE id_coffee='"+id_coffee+"'";
        db.simpanData(sql);
        System.out.println("");
    }
    
    

    public void simpan_akun(){
        String sql="INSERT INTO db_coffee_akun values('"+nama+"','"+email+"','"+password_akun+"')";
        db.simpanData(sql);
    }
    
    public void update_akun(){
        String sql="UPDATE db_coffee_akun SET nama='"+nama+"',email='"+email+"',password_akun='"+password_akun+"' WHERE id_akun='"+id_akun+"'";
        db.simpanData(sql);
        System.out.println(sql);
    }
    public void hapus_akun(){
        String sql="DELETE FROM db_coffee_akun WHERE id_akun='"+id_akun+"'";
        db.simpanData(sql);
        System.out.println("");
    }

    public void setId_coffee(String id_coffee) {
        this.id_coffee = id_coffee;
    }

    public String getId_coffee() {
        return id_coffee;
    }

    public void setCoffee_name(String coffee_name) {
        this.coffee_name = coffee_name;
    }

    public String getCoffee_name() {
        return coffee_name;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getStock() {
        return stock;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPrice() {
        return price;
    }

    public void setExpired(String expired) {
        this.expired = expired;
    }

    public String getExpired() {
        return expired;
    }
    
    
    
   
    
    public List CoffeeDetail() {
        List<CoffeeModel> data = new ArrayList<CoffeeModel>();
        ResultSet rs = null;

        try {
            String sql = "select * from db_coffee_detail";
            rs = db.ambilData(sql);
            while (rs.next()) {
                CoffeeModel um = new CoffeeModel();
                um.setId_coffee(rs.getString("ID_Coffee"));
                um.setCoffee_name(rs.getString("Coffee_Name"));
                um.setStock(rs.getString("Stock"));
                um.setPrice(rs.getString("Price"));
                um.setExpired(rs.getString("Expired"));
                data.add(um);

            }
            db.diskonek(rs);
        } catch (Exception ex) {
            System.out.println("Terjadi Kesalahan Saat menampilkan data Field" + ex);
        }
        return data;
    }
    
    
    public List cariIdCoffee() {
        List<CoffeeModel> data = new ArrayList<CoffeeModel>();
        ResultSet rs = null;
        try {
            String sql = "SELECT * FROM db_coffee_detail WHERE id_coffee='"+id_coffee+"'";
            rs = db.ambilData(sql);
            while (rs.next()) {
                CoffeeModel mz = new CoffeeModel();
                mz.setId_coffee(rs.getString("id_coffee"));
                mz.setCoffee_name(rs.getString("coffee_name"));
                mz.setStock(rs.getString("stock"));
                mz.setPrice(rs.getString("price"));
                mz.setExpired(rs.getString("expired"));
                data.add(mz);

            }
            db.diskonek(rs);
        } catch (Exception ex) {
            System.out.println("Terjadi Kesalah Saat menampilkan Cari IdCoffee" + ex);
        }
        return data;
    }
    
    
    public List CoffeeAkun() {
        List<CoffeeModel> data = new ArrayList<CoffeeModel>();
        ResultSet rs = null;

        try {
            String sql = "select * from db_coffee_akun";
            rs = db.ambilData(sql);
            while (rs.next()) {
                CoffeeModel um = new CoffeeModel();
               um.setId_akun(rs.getString("id_akun"));
               um.setNama(rs.getString("nama"));
               um.setEmail(rs.getString("email"));
               um.setPassword(rs.getString("password_akun"));
               
                data.add(um);

            }
            db.diskonek(rs);
        } catch (Exception ex) {
            System.out.println("Terjadi Kesalahan Saat menampilkan data Field" + ex);
        }
        return data;
    }
    
    public List cariIdAkun() {
        List<CoffeeModel> data = new ArrayList<CoffeeModel>();
        ResultSet rs = null;
        try {
            String sql = "SELECT * FROM db_coffee_akun WHERE id_akun='"+id_akun+"'";
            rs = db.ambilData(sql);
            while (rs.next()) {
                CoffeeModel m = new CoffeeModel();
                m.setId_akun(rs.getString("id_akun"));
                m.setNama(rs.getString("nama"));
                m.setEmail(rs.getString("email"));
                m.setPassword(rs.getString("password_akun"));
                data.add(m);

            }
            db.diskonek(rs);
        } catch (Exception ex) {
            System.out.println("Terjadi Kesalah Saat menampilkan Cari IdAkun" + ex);
        }
        return data;
    }
    
    public List LoginUser(String email, String password_akun) {
        List data = new ArrayList();
        ResultSet rs = null;
        try {
            String sql = "select * from db_coffee_akun where email='" + email + "' and password_akun='" + password_akun + "'";
            rs = db.ambilData(sql);
            
            while (rs.next()) {
                CoffeeModel am = new CoffeeModel();
                am.setId_akun(rs.getString("id_akun"));
                am.setNama(rs.getString("nama"));      
                am.setEmail(rs.getString("email"));                
                am.setPassword(rs.getString("password_akun"));
                data.add(am);
            }
            db.diskonek(rs);
        } catch (Exception a) {
            System.out.println("Terjadi kesalahaan cari login user, pada :\n" + a);
        }
        return data;
    }
    
    public List LoginAdmin(String username, String password_admin) {
        List data = new ArrayList();
        ResultSet rs = null;
        try {
            String sql = "select * from db_coffee_admin where username='" + username + "' and password_admin='" + password_admin + "'";
            rs = db.ambilData(sql);
            
            while (rs.next()) {
                CoffeeModel am = new CoffeeModel();
                am.setId_admin(rs.getString("id_admin"));
                am.setUsername(rs.getString("username"));                   
                am.setPassoword_admin(rs.getString("password_admin"));
                data.add(am);
            }
            db.diskonek(rs);
        } catch (Exception a) {
            System.out.println("Terjadi kesalahaan cari login admin, pada :\n" + a);
        }
        return data;
    }
}
